# Financial News Aggregator Bot

## Overview

This is a Telegram bot that aggregates financial news from multiple RSS feeds, translates them to Russian, and posts them to a Telegram channel. The bot monitors major financial news sources including Bloomberg, Reuters, Investing.com, and RBC (Russian Business Consulting) for breaking news related to markets, economics, and geopolitics.

Key features:
- RSS feed parsing from multiple financial news sources
- Automatic translation of English content to Russian
- Breaking news keyword detection for priority content
- Deduplication to prevent posting the same news twice
- HTML cleaning and text summarization

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Components

**News Aggregation Pipeline**
- Uses `feedparser` library to parse RSS feeds from 4 major financial news sources
- Implements a deduplication mechanism via `POSTED` set to track already-sent articles
- Breaking news detection through keyword matching (trump, fed, rates, sanctions, oil, inflation, etc.)

**Translation Service**
- Integrates Google Translate via `googletrans` library (version 4.0.0-rc1)
- Translates news titles and summaries from English to Russian
- Includes error handling with fallback to original text

**Text Processing**
- HTML tag stripping using regex
- HTML entity unescaping
- Text truncation to 300 characters for readability

**Telegram Integration**
- Uses Telegram Bot API for message delivery
- Configured with hardcoded bot token and channel chat ID
- Posts formatted news summaries to a specific Telegram channel

### Design Decisions

1. **In-memory deduplication**: Uses a Python set (`POSTED`) to track sent articles. This is simple but means duplicates could reappear after bot restart. For a production system, persistent storage would be preferred.

2. **Synchronous processing**: The bot uses synchronous HTTP requests and translation calls. This keeps the code simple but may be slow when processing many feeds.

3. **Hardcoded configuration**: Bot credentials and feed URLs are hardcoded. Consider moving to environment variables for security.

## External Dependencies

### Python Libraries
- `feedparser` - RSS/Atom feed parsing
- `requests` - HTTP client for Telegram API calls
- `googletrans==4.0.0-rc1` - Google Translate unofficial API wrapper

### External Services
- **Telegram Bot API** - Message delivery to channels
- **Google Translate** - Text translation (via unofficial googletrans library)

### RSS Feed Sources
- Bloomberg (podcast feed)
- Reuters Business News
- Investing.com News
- RBC Finance (Russian)

### Security Note
The bot token is exposed in source code. This should be moved to environment variables (`os.environ.get('TELEGRAM_TOKEN')`) before deployment.